@extends('layout')

@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> Show News Detail</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('explore.index') }}"> Back</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nama Tempat Wisata:</strong>
                {{ $explores->nama_wisata}}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Foto:</strong>
                {{--  {{ $newss->handphone_number}}  --}}
                <img src="{{ $explores -> foto }}" style="height:300px;width:300px;text-align:center">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Alamat:</strong>
                {{ $explores->alamat}}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Langitude:</strong>
                {{ $explores->lang}}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Longitude:</strong>
                {{ $explores->long}}
            </div>
        </div>
    </div>
@endsection