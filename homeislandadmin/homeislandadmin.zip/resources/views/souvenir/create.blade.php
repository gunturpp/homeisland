@extends('layout')

@section('content')
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Add New Souvenir</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('souvenir.index') }}"> Back</a>
            </div>
        </div>
    </div>
    
    {!! Form::open(['route' => 'souvenir.store','method'=>'POST','files'=>true]) !!}
         @include('souvenir.form')
    {!! Form::close() !!}

@endsection