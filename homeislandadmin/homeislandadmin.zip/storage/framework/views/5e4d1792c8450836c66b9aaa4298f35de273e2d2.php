



    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nama Homestay:</strong>
                <?php echo Form::text('nama_homestay', null, array('placeholder' => 'Nama Homestay','class' => 'form-control')); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Harga:</strong>
                <?php echo Form::number('harga', null, array('placeholder' => 'harga','class' => 'form-control')); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Kuota:</strong>
                <?php echo Form::number('kuota', null, array('placeholder' => 'kuota','class' => 'form-control')); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Latitude:</strong>
                <?php echo Form::text('lat', null, array('placeholder' => 'Latitude','class' => 'form-control')); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Longitude:</strong>
                <?php echo Form::text('long', null, array('placeholder' => 'Longitude','class' => 'form-control')); ?>

            </div>
        </div>

        

            

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-horizontal ">
                    <strong>Foto 1:</strong>
                    <?php echo Form::file('foto_1', array('class' => 'image')); ?>

                    
                </div>
                <br />
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-horizontal">
                    <strong>Foto 2:</strong>
                    <?php echo Form::file('foto_2', null, array('class' => 'image')); ?>

                </div>
                <br />
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-horizontal">
                    <strong>Foto 3:</strong>
                    <?php echo Form::file('foto_3', null, array('class' => 'image')); ?>

                </div>
            </div>

            <br />

            

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.
                    <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            

        
        <br />
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>




</div>